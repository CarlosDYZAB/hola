#include <iostream>
#include <string>
#include <SDL.h>

#pragma comment(lib, "SDL2.lib")
#pragma comment(lib, "SDL2main.lib")

int maxX = 640;
int maxY = 480;

int main(int argc, char **argv) {

	/*if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
	std::cerr << "SDL_Init error: " << SDL_GetError() << std::endl;
	return 1;
	}*/
	
	SDL_Window* win = SDL_CreateWindow("Awesome Rectangle", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, maxX, maxY, SDL_WINDOW_SHOWN);

	SDL_Renderer* renderer = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

	SDL_Rect r;
	r.x = 150;
	r.y = 150;
	r.w = 160;
	r.h = 110;
	SDL_Rect c;
	

	int speedx = 0;
	int speedy = 0;
	int speedc = 20;

	SDL_Event event;
	int close = 0;
	while (true)
	{
		const Uint8* states = SDL_GetKeyboardState(NULL);
		SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);

		//CLEANS THE RENDERED STUFF THAT WAS THERE BEFORE IN HE COLOR SET UP
		SDL_RenderClear(renderer);
		
		//MOVE THE SQUARE POSITION
		if (SDL_PollEvent(&event)) {
			switch (event.type) {
				case SDL_QUIT: //COMAND THAT ALLOW US TO CLOSE THE WINDOW
					close = 1;
					break;

				case SDL_KEYDOWN:
				switch (event.key.keysym.sym) {
					case SDLK_LEFT:
						if (r.x == 0) {
							speedx += 0;
						}
						else {
							speedx += -10;
							r.x += speedx;
						}

						break;

					case SDLK_RIGHT:
						if (r.x == maxX - r.w) {
							speedx += 0;
						}
						else {
							speedx += 10;
							r.x += speedx;
						}
						break;

					case SDLK_UP:
						if (r.y == 0) {
							speedy += 0;
						}
					else {
						speedy += -10;
						r.y += speedy;
					}
					break;

				case SDLK_DOWN:
					if (r.y == maxY - r.h) {
						speedy += 0;
					}
					else {
						speedy += 10;
						r.y += speedy;
					}
					break;
				case SDLK_SPACE:
					
					c.w = 80;
					c.h = 40;
					speedc = 10;
					c.y = r.y + (r.h - c.h)/2;
					c.x = r.x;
					for (int i = 0; i < 50; i++) {
						c.x += speedc;
						SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
						SDL_RenderFillRect(renderer, &c);
					}
					
					break;
					
					speedx = 0;
					speedy = 0;
				}
				case SDL_KEYUP:
					switch (event.key.keysym.sym) {
					case SDLK_LEFT:
						if (speedx < 0){
							speedx = 0;}
						break;
					case SDLK_RIGHT:
						if (speedx > 0){
							speedx = 0;}
						break;
					case SDLK_UP:
						if (speedy < 0){
							speedy = 0;}
						break;
					case SDLK_DOWN:
						if (speedy > 0){
							speedy = 0;}
						break;
					default:
						break;
					}
			}



		}
		/*
		if (states[SDL_SCANCODE_LEFT]){
			if (r.x == 0) {
				speedx += 0;
			}
			else {
				speedx += -10;
				r.x += speedx;
			}
		}
		else if (states[SDL_SCANCODE_RIGHT]){
			if (r.x == maxX - r.w) {
				speedx += 0;
			}
			else {
				speedx += 10;
				r.x += speedx;
			}
		}*/
		
		SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
		SDL_RenderFillRect(renderer, &c);
		
			
			//CHANGE THE COLOR OF THE RENDERER
			SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);

			//RENDER THE SQUARE WITH NEW POSITION AND NEW COLOR
			SDL_RenderFillRect(renderer, &r);
			SDL_RenderPresent(renderer);
			SDL_Delay(10);
			
	}


		SDL_Delay(100);
		SDL_DestroyWindow(win);
		SDL_Quit();
		return 0;
	
}
void ChangeX(SDL_Rect &c, int &changer)
{

}

void ChangeY(SDL_Rect &c, int &changer)
{

}